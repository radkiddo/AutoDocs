(function ($) {

	var countries = ['AFGANISTAN',
		'ALBANIA',
		'ARGELIA',
		'SAMOA AMERICANA',
		'ANDORRA',
		'ANGOLA',
		'ANGUILLA',
		'ANTARCTIDA',
		'ANTIGUA Y BARBUDA',
		'ARGENTINA',
		'ARMENIA',
		'ARUBA',
		'AUSTRALIA',
		'AUSTRIA',
		'AZERBAIJAN',
		'BAHAMAS',
		'BAHRAIN',
		'BANGLADESH',
		'BARBADOS',
		'BELARUS',
		'BELGICA',
		'BELIZE',
		'BENIN',
		'BERMUDA',
		'BHUTAN',
		'BOLIVIA',
		'BONAIRE',
		'BOSNIA Y HERZEGOVINA',
		'BOTSWANA',
		'BRASIL',
		'BRUNEI',
		'BULGARIA',
		'BURKINA FASO',
		'BURUNDI',
		'CAMBODIA',
		'CAMEROON',
		'CANADA',
		'CABO VERDE',
		'ISLAS CAIMAN',
		'REP CENTRO AFRICANA',
		'CHAD',
		'CHILE',
		'CHINA',
		'ISLAS CHRISTMA',
		'ISLAS COCOS KEELING',
		'COLOMBIA',
		'COMOROS',
		'CONGO',
		'REP DEM CONGO',
		'ISLAS COOK',
		'COSTA RICA',
		'COSTA DE MARFIL',
		'CROACIA',
		'CUBA',
		'CURACAO',
		'CHIPRE',
		'REP CHECA',
		'DINAMARCA',
		'DJIBOUTI',
		'DOMINICA',
		'REP DOMINICANA',
		'ECUADOR',
		'EGIPTO',
		'EL SALVADOR',
		'GUINEA ECUATORIAL',
		'ERITREA',
		'ESTONIA',
		'ETIOPIA',
		'ISLAS FAROE',
		'FIJI',
		'FINLANDIA',
		'FRANCIA',
		'GUYANA FRANCESA',
		'POLINESIA FRANCESA',
		'GABON',
		'GAMBIA',
		'GEORGIA',
		'ALEMANIA',
		'GHANA',
		'GIBRALTAR',
		'GRECIA',
		'GROENLANDIA',
		'GRENADA',
		'GUADELUPE',
		'GUAM',
		'GUATEMALA',
		'GUERNSEY',
		'GUINEA',
		'GUINEA-BISSAU',
		'GUYANA',
		'HAITI',
		'ISLAS MCDONALD',
		'VATICANO',
		'HONDURAS',
		'HONG KONG',
		'HUNGARY',
		'ISLANDIA',
		'INDIA',
		'INDONESIA',
		'IRAN',
		'IRAK',
		'IRLANDA',
		'ISLA DE MAN',
		'ISRAEL',
		'ITALIA',
		'JAMAICA',
		'JAPAN',
		'JERSEY',
		'JORDANIA',
		'KAZAKHSTAN',
		'KENIA',
		'KIRIBATI',
		'NORKOREA',
		'SURKOREA',
		'KUWAIT',
		'KIRGYZSTAN',
		'LAO',
		'LETONIA',
		'LIBANO',
		'LESOTHO',
		'LIBERIA',
		'LIBIA',
		'LIECHTENSTEIN',
		'LITHUANIA',
		'LUXEMBURGO',
		'MACAO',
		'MACEDONIA',
		'MADAGASCAR',
		'MALAWI',
		'MALASIA',
		'MALDIVAS',
		'MALI',
		'MALTA',
		'ISLAS MARSHALL',
		'MARTINICA',
		'MAURITANIA',
		'MAURICIOS',
		'MAYOTE',
		'MEXICO',
		'MICRONESIA',
		'MOLDOVIA',
		'MONACO',
		'MONGOLIA',
		'MONTENEGRO',
		'MONTSERRAT',
		'MARRUECOS',
		'MOZAMBIQUE',
		'MYANMAR',
		'NAMIBIA',
		'NAURU',
		'NEPAL',
		'PAISES BAJOS',
		'NUEVA CALEDONIA',
		'NUEVA ZELANDA',
		'NICARAGUA',
		'NIGER',
		'NIGERIA',
		'ISLAS NORFOLK',
		'ISLAS MARIANAS',
		'NORUEGA',
		'OMAN',
		'PAKISTAN',
		'PALAU',
		'PALESTINA',
		'PANAMA',
		'PAPUA NUEVA GUINEA',
		'PARAGUAY',
		'PERU',
		'FILIPINAS',
		'POLONIA',
		'PORTUGAL',
		'PUERTO RICO',
		'QATAR',
		'REUNION',
		'RUMANIA',
		'RUSSIA',
		'RUANDA',
		'SAN KITTS Y NEVIS',
		'SANTA LUCIA',
		'SAN PIERRE Y MIQUELON',
		'SAN VINCENTE Y GRENADINES',
		'SAMOA',
		'SAN MARINO',
		'SAN TOME Y PRINCIPE',
		'ARABIA SAUDI',
		'SENEGAL',
		'SERBIA',
		'SEYCHELLES',
		'SIERRA LEON',
		'SINGAPORE',
		'SAN MAARTEN',
		'ESLOVAKIA',
		'ESLOVENIA',
		'ISLAS SOLOMON',
		'SOMALIA',
		'SUDAFRICA',
		'SUDAN DEL SUR',
		'ESPAÑA',
		'SRI LANKA',
		'SUDAN',
		'SURINAM',
		'SUAZILANDIA',
		'SUECIA',
		'SUIZA',
		'SYRIA',
		'TAIWAN',
		'TAJIKISTAN',
		'TANZANIA',
		'TAILANDIA',
		'TIMOR-LESTE',
		'TOGO',
		'TOKELAU',
		'TONGA',
		'TRINIDAD Y TOBAGO',
		'TUNES',
		'TURQUIA',
		'TURKMENISTAN',
		'TURKS Y CAICOS',
		'TUVALU',
		'UGANDA',
		'UCRANIA',
		'EMIRATES ARABES',
		'REINO UNIDO',
		'ESTADOS UNIDOS',
		'URUGUAY',
		'UZBEKISTAN',
		'VANUATU',
		'VENEZUELA',
		'VIETNAM',
		'WALLIS Y FUTUNA',
		'SAHARA OCCIDENTAL',
		'YEMEN',
		'ISLAS VIRGENES UK',
		'ISLAS VIRGENES US',
		'ZAMBIA',
		'ZIMBABUE'],

		sx = ['Masculino', 'Femenino'],

		ec = ['Casada/o', 'Soltera/o', 'Divorciada/o', 'Viuda/o'];

	isValidCountry = function(c) {
		var result = false;

		for (var i = 0; i <= countries.length - 1; i++) {
			var item = countries[i];

			if (c.toLowerCase() === item.toLowerCase()) {
				result = true;
				break;
			}
		}

		return result;
	};

    isValidCedula = function(cedula) {
    	var pattern = new RegExp(/^[[V|E|J|G]\d\d\d\d\d\d\d\d]{0,9}$/);

        return pattern.test(cedula);
    };

    isValidAlphaNum = function(str) {
    	var pattern = new RegExp(/^[0-9a-zA-Z]+$/);

    	return pattern.test(str);
    };

    isValidLetter = function(str) {
    	var pattern = new RegExp(/^[a-zA-Z]+$/);

    	return pattern.test(str);
    };

    isValidASpaces = function(str) {
    	var pattern = new RegExp(/[a-zA-Z ]+/);

    	return pattern.test(str);
    };

    isValidSexo = function(str) {
    	var result = false;

    	for (var i = 0; i <= sx.length - 1; i++) {
    		if (str.toLowerCase() === sx[i].toLowerCase()) {
    			result = true;
    			break;
    		}
    	}

    	return result;
    };

    isValidEstadoCivil = function(str, sexo) {
    	var result = false,
    		arr = ec;

    	for (var i = 0; i <= arr.length - 1; i++) {
    		if (str.toLowerCase() === arr[i].toLowerCase()) {
    			result = true;
    			break;
    		}
    	}

    	return result;
    };

    isValidAlphaSpaces = function(str) {
    	var result = true;

    	if (str.length > 0) {
    		if (isValidLetter(str[0])) {
    			for (var i = 0; i <= str.length - 1; i++) {
    				if (str[i] !== ' ') {
    					if (!isValidAlphaNumLatin(str[i])) {
    						result = false;
    						break;
    					}
    				}
    			}
    		}
    		else {
    			result = false;
    		}
    	}

    	return result;
    };

    isValidAlphaNumLatin = function(str) {
    	var pattern = new RegExp(/^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]+$/);

    	return pattern.test(str);
    };

    isValidDate = function(str) {
    	var pattern = new RegExp(/^(?=\d{2}([-.,\/])\d{2}\1\d{4}$)(?:0[1-9]|1\d|[2][0-8]|29(?!.02.(?!(?!(?:[02468][1-35-79]|[13579][0-13-57-9])00)\d{2}(?:[02468][048]|[13579][26])))|30(?!.02)|31(?=.(?:0[13578]|10|12))).(?:0[1-9]|1[012]).\d{4}$/);

    	return pattern.test(str);
    };

    getAge = function(dateString) {
    	var dates = dateString.split('/');
	    var d = new Date();

	    var userday = dates[0];
	    var usermonth = dates[1];
	    var useryear = dates[2];

	    var curday = d.getDate();
	    var curmonth = d.getMonth()+1;
	    var curyear = d.getFullYear();

	    var age = curyear - useryear;

	    if((curmonth < usermonth) || ( (curmonth == usermonth) && curday < userday   )){
	        age--;
	    }

	    return age;
	};

	isValidWorkingAge = function(age) {
		return (getAge(age) >= 18) ? true : false;
	};

	isValidDateWorkingAge = function(str) {
		return (isValidDate(str) && isValidWorkingAge(str)) ? true : false;
	}

    fieldOnKey = function(e, isValidFunc, field, extraField, msg, nextField, canEmptyStr) {
    	var str = $(field).val(),
    		exStr = (extraField === undefined) ? $(extraField).val() : '',
    		result = false;

		if (str !== '') {
			var funcRes = (extraField === undefined) ? isValidFunc(str) : isValidFunc(str, exStr);

			if (!funcRes) {
				$(msg).show();	
			}
			else {
				$(msg).hide();

				if (e !== undefined && e.which === 13 && nextField !== undefined) {
					$(nextField).focus();
				}

				result = true;
			}
		}
		else {
			$(msg).hide();
			
			result = (canEmptyStr) ? true : false;
		}

		return result;
    };

	// Login
	(function (login, $, undefined) {
	
		var _l = {
		};
		
		//
	
	}(window.login = window.login || {}, window.jQuery));

	//Clinicas
	(function (clinicas, $, undefined) {

		var _c = {

			cleanFields : function() {
				$('#fd_ClinicasWebsClinica').val('');
				$('#fd_ClinicasEmailsClinica').val('');
				$('#fd_ClinicasTelefonosClinica').val('');
				$('#fd_ClinicasDireccionClinica').val('');
				$('#fd_ClinicasNombreClinica').val('');
				$('#fd_ClinicasCedula').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainClinicasDiv').hide();
			},

			cancelarClinicas : function() {
				_c.cleanFields();

				$('#fd_MainClinicasDiv').show();

				$('#fd_ClinicasFieldsDiv').hide();
				$('#fd_ClinicasFieldsDivMain').hide();
			},

			showfd_ClinicasFieldsDivMain : function(caption) {
				$('#fd_ClinicasFieldsDivCaption').text(caption);

				_c.hideMainBtns();
				_c.cleanFields();

				$('#fd_ClinicasFieldsDiv').show();
				$('#fd_ClinicasFieldsDivMain').show();
			},

			isValidClinicas : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_ClinicasCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_ClinicasCedula', '#fd_ClinicasCedulaNoValida', '#fd_ClinicasNombreClinica');

			if (_c.isValidClinicas()) {
				$('#fd_GuardarClinicas').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoClinica').click(function(e) {
			e.preventDefault();

			_c.showfd_ClinicasFieldsDivMain('Nueva Clinica');
			$('#fd_ClinicasCedula').focus();

			$('#fd_GuardarClinicas').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarClinicas').click(function(e) {
			e.preventDefault();

			_c.cancelarClinicas();

			return false;
		});

	}(window.clinicas = window.clinicas || {}, window.jQuery));
	
	//Examenes
	(function (examenes, $, undefined) {

		var _e = {
			cleanFields : function() {
				$('#fd_ExamenesResultadoExamen').val('');
				$('#fd_ExamenesFechaCaducidad').val('');
				$('#fd_ExamenesFechaExamen').val('');
				$('#fd_ExamenesNombreExamen').val('');
				$('#fd_ExamenesCedula').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainExamenesDiv').hide();
			},

			cancelarExamenes : function() {
				_e.cleanFields();

				$('#fd_MainExamenesDiv').show();

				$('#fd_ExamenesFieldsDiv').hide();
				$('#fd_ExamenesFieldsDivMain').hide();
			},

			showfd_ExamenesFieldsDivMain : function(caption) {
				$('#fd_ExamenesFieldsDivCaption').text(caption);

				_e.hideMainBtns();
				_e.cleanFields();

				$('#fd_ExamenesFieldsDiv').show();
				$('#fd_ExamenesFieldsDivMain').show();
			},

			isValidExamenes : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_ExamenesCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_ExamenesCedula', '#fd_ExamenesCedulaNoValida', '#fd_ExamenesNombreExamen');

			if (_e.isValidExamenes()) {
				$('#fd_GuardarExamenes').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoExamen').click(function(e) {
			e.preventDefault();

			_e.showfd_ExamenesFieldsDivMain('Nuevo Examen');
			$('#fd_ExamenesCedula').focus();

			$('#fd_GuardarExamenes').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarExamenes').click(function(e) {
			e.preventDefault();

			_e.cancelarExamenes();

			return false;
		});

	}(window.examenes = window.examenes || {}, window.jQuery));

	//Cargos
	(function (cargos, $, undefined) {

		var _c = {
			cleanFields : function() {
				$('#fd_CargosCedula').val('');
				$('#fd_CargosCargo').val('');
				$('#fd_CargosSueldo').val('');
				$('#fd_CargosBono').val('');
				$('#fd_CargosMesesDisfrute').val('');
				$('#fd_CargosDiasDisfrute').val('');
				$('#fd_CargosDiasPago').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainCargosDiv').hide();
			},

			cancelarCargos : function() {
				_c.cleanFields();

				$('#fd_MainCargosDiv').show();

				$('#fd_CargosFieldsDiv').hide();
				$('#fd_CargosFieldsDivMain').hide();
			},

			showfd_CargosFieldsDivMain : function(caption) {
				$('#fd_CargosFieldsDivCaption').text(caption);

				_c.hideMainBtns();
				_c.cleanFields();

				$('#fd_CargosFieldsDiv').show();
				$('#fd_CargosFieldsDivMain').show();
			},

			isValidCargos : function() {
				var result = false;

				//

				return result;
			}			
		};

		$('#fd_CargosCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_CargosCedula', '#fd_CargosCedulaNoValida', '#fd_CargosCargo');

			if (_c.isValidCargos()) {
				$('#fd_GuardarCargos').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoCargo').click(function(e) {
			e.preventDefault();

			_c.showfd_CargosFieldsDivMain('Nuevo Cargo');
			$('#fd_CargosCedula').focus();

			$('#fd_GuardarCargos').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarCargos').click(function(e) {
			e.preventDefault();

			_c.cancelarCargos();

			return false;
		});

	}(window.cargos = window.cargos || {}, window.jQuery));

	//Familiares
	(function (familiares, $, undefined) {

		var _f = {
			cleanFields : function() {
				$('#fd_FamiliaresCedula').val('');
				$('#fd_FamiliaresCedulaFamiliar').val('');
				$('#fd_FamiliaresNombreFamiliar').val('');
				$('#fd_FamiliaresApellidosFamiliar').val('');
				$('#fd_FamiliaresSexoFamiliar').val('');
				$('#fd_FamiliaresDesdeFamiliar').val('');
				$('#fd_FamiliaresHastaFamiliar').val('');
				$('#fd_FamiliaresNumeroHijos').val('');
				$('#fd_FamiliaresFechaNacimientoFamiliar').val('');
				$('#fd_FamiliaresLugarNacimientoFamiliar').val('');
				$('#fd_FamiliaresProvinciaNacimientoFamiliar').val('');
				$('#fd_FamiliaresPaisNacimientoFamiliar').val('');
				$('#fd_FamiliaresProfesionFamiliar').val('');
				$('#fd_FamiliaresTelefonosFamiliar').val('');
				$('#fd_FamiliaresDireccionFamiliar').val('');
				$('#fd_FamiliaresEmailsFamiliar').val('');
				$('#fd_FamiliaresWebsFamiliar').val('');
				$('#fd_FamiliaresDependienteFamiliar').val('');
				$('#fd_FamiliaresCohabitaFamiliar').val('');
				$('#fd_FamiliaresFechaDefuncionFamiliar').val('');
				$('#fd_FamiliaresParentescoFamiliar').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainFamiliaresDiv').hide();
			},

			cancelarFamiliares : function() {
				_f.cleanFields();

				$('#fd_MainFamiliaresDiv').show();

				$('#fd_FamiliaresFieldsDiv').hide();
				$('#fd_FamiliaresFieldsDivMain').hide();
			},

			showfd_FamiliaresFieldsDivMain : function(caption) {
				$('#fd_FamiliaresFieldsDivCaption').text(caption);

				_f.hideMainBtns();
				_f.cleanFields();

				$('#fd_FamiliaresFieldsDiv').show();
				$('#fd_FamiliaresFieldsDivMain').show();
			},

			isValidFamiliares : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_FamiliaresCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_FamiliaresCedula', '#fd_FamiliaresCedulaNoValida', '#fd_FamiliaresCedulaFamiliar');

			if (_f.isValidFamiliares()) {
				$('#fd_GuardarFamiliares').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoFamiliar').click(function(e) {
			e.preventDefault();

			_f.showfd_FamiliaresFieldsDivMain('Nuevo Familiar');
			$('#fd_FamiliaresCedula').focus();

			$('#fd_GuardarFamiliares').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarFamiliares').click(function(e) {
			e.preventDefault();

			_f.cancelarFamiliares();

			return false;
		});

	}(window.familiares = window.familiares || {}, window.jQuery));

	//Visas
	(function (visas, $, undefined) {

		var _v = {
			cleanFields : function() {
				$('#fd_VisasCedula').val('');
				$('#fd_VisasNumeroPasaporte').val('');
				$('#fd_VisasTipoVisa').val('');
				$('#fd_VisasLugarExpedicion').val('');
				$('#fd_VisasFechaExpedicion').val('');
				$('#fd_VisasFechaCaducidad').val('');
				$('#fd_VisasNumeroEntradas').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainVisasDiv').hide();
			},

			cancelarVisas : function() {
				_v.cleanFields();

				$('#fd_MainVisasDiv').show();

				$('#fd_VisasFieldsDiv').hide();
				$('#fd_VisasFieldsDivMain').hide();
			},

			showfd_VisasFieldsDivMain : function(caption) {
				$('#fd_VisasFieldsDivCaption').text(caption);

				_v.hideMainBtns();
				_v.cleanFields();

				$('#fd_VisasFieldsDiv').show();
				$('#fd_VisasFieldsDivMain').show();
			},

			isValidVisas : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_VisasCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_VisasCedula', '#fd_VisasCedulaNoValida', '#fd_VisasNumeroPasaporte');

			if (_v.isValidVisas()) {
				$('#fd_GuardarVisas').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoVisa').click(function(e) {
			e.preventDefault();

			_v.showfd_VisasFieldsDivMain('Nueva Visa');
			$('#fd_VisasCedula').focus();

			$('#fd_GuardarVisas').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarVisas').click(function(e) {
			e.preventDefault();

			_v.cancelarVisas();

			return false;
		});

	}(window.visas = window.visas || {}, window.jQuery));

	//Nacionalidades
	(function (nacionalidades, $, undefined) {

		var _n = {
			cleanFields : function() {
				$('#fd_NacionalidadesCedula').val('');
				$('#fd_NacionalidadesNombre').val('');
				$('#fd_NacionalidadesNumeroPasaporte').val('');
				$('#fd_NacionalidadesNombresPasaporte').val('');
				$('#fd_NacionalidadesApellidosPasaporte').val('');
				$('#fd_NacionalidadesFechaExpedicion').val('');
				$('#fd_NacionalidadesFechaCaducidad').val('');
				$('#fd_NacionalidadesLugarExpedicion').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainNacionalidadesDiv').hide();
			},

			cancelarNacionalidades : function() {
				_n.cleanFields();

				$('#fd_MainNacionalidadesDiv').show();

				$('#fd_NacionalidadesFieldsDiv').hide();
				$('#fd_NacionalidadesFieldsDivMain').hide();
			},

			showfd_NacionalidadesFieldsDivMain : function(caption) {
				$('#fd_NacionalidadesFieldsDivCaption').text(caption);

				_n.hideMainBtns();
				_n.cleanFields();

				$('#fd_NacionalidadesFieldsDiv').show();
				$('#fd_NacionalidadesFieldsDivMain').show();
			},

			isValidNacionalidades : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_NacionalidadesCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_NacionalidadesCedula', '#fd_NacionalidadesCedulaNoValida', '#fd_NacionalidadesNombre');

			if (_n.isValidNacionalidades()) {
				$('#fd_GuardarNacionalidades').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoNacionalidad').click(function(e) {
			e.preventDefault();

			_n.showfd_NacionalidadesFieldsDivMain('Nueva Nacionalidad');
			$('#fd_NacionalidadesCedula').focus();

			$('#fd_GuardarNacionalidades').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarNacionalidades').click(function(e) {
			e.preventDefault();

			_n.cancelarNacionalidades();

			return false;
		});

	}(window.nacionalidades = window.nacionalidades || {}, window.jQuery));

	//Certificados
	(function (certificados, $, undefined) {

		var _c = {
			cleanFields : function() {
				$('#fd_CertificadosCedula').val('');
				$('#fd_CertificadosNombre').val('');
				$('#fd_CertificadosFechaExpedicion').val('');
				$('#fd_CertificadosFechaCaducidad').val('');
				$('#fd_CertificadosNumeroCertificado').val('');
				$('#fd_CertificadosLugarExpedicion').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainCertificadosDiv').hide();
			},

			cancelarCertificados : function() {
				_c.cleanFields();

				$('#fd_MainCertificadosDiv').show();

				$('#fd_CertificadosFieldsDiv').hide();
				$('#fd_CertificadosFieldsDivMain').hide();
			},

			showfd_CertificadosFieldsDivMain : function(caption) {
				$('#fd_CertificadosFieldsDivCaption').text(caption);

				_c.hideMainBtns();
				_c.cleanFields();

				$('#fd_CertificadosFieldsDiv').show();
				$('#fd_CertificadosFieldsDivMain').show();
			},

			isValidCertificados : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_CertificadosCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_CertificadosCedula', '#fd_CertificadosCedulaNoValida', '#fd_CertificadosNombre');

			if (_c.isValidCertificados()) {
				$('#fd_GuardarCertificados').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoCertificado').click(function(e) {
			e.preventDefault();

			_c.showfd_CertificadosFieldsDivMain('Nuevo Certificado');
			$('#fd_CertificadosCedula').focus();

			$('#fd_GuardarCertificados').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarCertificados').click(function(e) {
			e.preventDefault();

			_c.cancelarCertificados();

			return false;
		});

	}(window.certificados = window.certificados || {}, window.jQuery));

	//Idiomas
	(function (idiomas, $, undefined) {

		var _i = {
			cleanFields : function() {
				$('#fd_IdiomasCedula').val('');
				$('#fd_IdiomasNombre').val('');
				$('#fd_IdiomasNivelLectura').val('');
				$('#fd_IdiomasNivelEscrito').val('');
				$('#fd_IdiomasNivelHablado').val('');
				$('#fd_IdiomasAcento').val('');
				$('#fd_IdiomasLugarAprendizaje').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainIdiomasDiv').hide();
			},

			cancelarIdiomas : function() {
				_i.cleanFields();

				$('#fd_MainIdiomasDiv').show();

				$('#fd_IdiomasFieldsDiv').hide();
				$('#fd_IdiomasFieldsDivMain').hide();
			},

			showfd_IdiomasFieldsDivMain : function(caption) {
				$('#fd_IdiomasFieldsDivCaption').text(caption);

				_i.hideMainBtns();
				_i.cleanFields();

				$('#fd_IdiomasFieldsDiv').show();
				$('#fd_IdiomasFieldsDivMain').show();
			},

			isValidIdiomas : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_IdiomasCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_IdiomasCedula', '#fd_IdiomasCedulaNoValida', '#fd_EmbarquesCapitan');

			if (_i.isValidIdiomas()) {
				$('#fd_GuardarIdiomas').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoIdioma').click(function(e) {
			e.preventDefault();

			_i.showfd_IdiomasFieldsDivMain('Nuevo Idioma');
			$('#fd_IdiomasCedula').focus();

			$('#fd_GuardarIdiomas').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarIdiomas').click(function(e) {
			e.preventDefault();

			_i.cancelarIdiomas();

			return false;
		});

	}(window.idiomas = window.idiomas || {}, window.jQuery));

	//Embarques
	(function (embarques, $, undefined) {

		var _e = {

			cleanFields : function() {
				$('#fd_EmbarquesCedula').val('');
				$('#fd_EmbarquesCapitan').val('');
				$('#fd_EmbarquesBuque').val('');
				$('#fd_EmbarquesClaseBuque').val('');
				$('#fd_EmbarquesCargoBuque').val('');
				$('#fd_EmbarquesFechaEmbarque').val('');
				$('#fd_EmbarquesFechaDesembarque').val('');
				$('#fd_EmbarquesCausaDesembarque').val('');
				$('#fd_EmbarquesPuertoBuque').val('');
				$('#fd_EmbarquesBanderaBuque').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainEmbarquesDiv').hide();
			},

			cancelarEmbarques : function() {
				_e.cleanFields();

				$('#fd_MainEmbarquesDiv').show();

				$('#fd_EmbarquesFieldsDiv').hide();
				$('#fd_EmbarquesFieldsDivMain').hide();
			},

			showfd_EmbarquesFieldsDivMain : function(caption) {
				$('#fd_EmbarquesFieldsDivCaption').text(caption);

				_e.hideMainBtns();
				_e.cleanFields();

				$('#fd_EmbarquesFieldsDiv').show();
				$('#fd_EmbarquesFieldsDivMain').show();
			},

			isValidEmbarques : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_EmbarquesCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_EmbarquesCedula', '#fd_EmbarquesCedulaNoValida', '#fd_EmbarquesCapitan');

			if (_e.isValidEmbarques()) {
				$('#fd_GuardarEmbarques').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoEmbarque').click(function(e) {
			e.preventDefault();

			_e.showfd_EmbarquesFieldsDivMain('Nuevo Embarque');
			$('#fd_EmbarquesCedula').focus();

			$('#fd_GuardarEmbarques').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarEmbarques').click(function(e) {
			e.preventDefault();

			_e.cancelarEmbarques();

			return false;
		});

	}(window.embarques = window.embarques || {}, window.jQuery));

	//Datos-Personales
	(function (datosPersonales, $, undefined) {

		var _p = {

			cleanFields : function() {
				$('#fd_DatosPersonalesCedula').val('');
				$('#fd_DatosPersonalesTelefonos').val('');
				$('#fd_DatosPersonalesDireccion').val('');
				$('#fd_DatosPersonalesEmails').val('');
				$('#fd_DatosPersonalesWebs').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainDatosPersonalesDiv').hide();
			},

			cancelarDatosPersonales : function() {
				_p.cleanFields();

				$('#fd_MainDatosPersonalesDiv').show();

				$('#fd_DatosPersonalesFieldsDiv').hide();
				$('#fd_DatosPersonalesFieldsDivMain').hide();
			},

			showfd_DatosPersonalesFieldsDivMain : function(caption) {
				$('#fd_DatosPersonalesFieldsDivCaption').text(caption);

				_p.hideMainBtns();
				_p.cleanFields();

				$('#fd_DatosPersonalesFieldsDiv').show();
				$('#fd_DatosPersonalesFieldsDivMain').show();
			},

			isValidDatosPersonales : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_DatosPersonalesCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_DatosPersonalesCedula', '#fd_DatosPersonalesCedulaNoValida', '#fd_DatosPersonalesTelefonos');

			if (_p.isValidDatosPersonales()) {
				$('#fd_GuardarDatosPersonales').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoDatosPersonales').click(function(e) {
			e.preventDefault();

			_p.showfd_DatosPersonalesFieldsDivMain('Nuevo Dato-Personal');
			$('#fd_DatosPersonalesCedula').focus();

			$('#fd_GuardarDatosPersonales').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarDatosPersonales').click(function(e) {
			e.preventDefault();

			_p.cancelarDatosPersonales();

			return false;
		});

	}(window.datosPersonales = window.datosPersonales || {}, window.jQuery));

	//Datos-fisicos
	(function (datosFisicos, $, undefined) {

		var _d = {

			cleanFields : function() {
				$('#fd_DatosFisicosCedula').val('');
				$('#fd_DatosFisicosPeso').val('');
				$('#fd_DatosFisicosEstatura').val('');
				$('#fd_DatosFisicosTalla').val('');
				$('#fd_DatosFisicosZapatos').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainDatosFisicosDiv').hide();
			},

			cancelarDatosFisicos : function() {
				_d.cleanFields();

				$('#fd_MainDatosFisicosDiv').show();

				$('#fd_DatosFisicosFieldsDiv').hide();
				$('#fd_DatosFisicosFieldsDivMain').hide();
			},

			showfd_DatosFisicosFieldsDivMain : function(caption) {
				$('#fd_DatosFisicosFieldsDivCaption').text(caption);

				_d.hideMainBtns();
				_d.cleanFields();

				$('#fd_DatosFisicosFieldsDiv').show();
				$('#fd_DatosFisicosFieldsDivMain').show();
			},

			isValidDatosFisicos : function() {
				var result = false;

				//

				return result;
			}
		};

		$('#fd_DatosFisicosCedula').keyup(function (e) {
			cedulaOnKey(e, '#fd_DatosFisicosCedula', '#fd_DatosFisicosCedulaNoValida', '#fd_DatosFisicosPeso');

			if (_d.isValidDatosFisicos()) {
				$('#fd_GuardarDatosFisicos').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
			}
		});

		$('#fd_NuevoDatosFisicos').click(function(e) {
			e.preventDefault();

			_d.showfd_DatosFisicosFieldsDivMain('Nuevo Dato-Fisico');
			$('#fd_DatosFisicosCedula').focus();

			$('#fd_GuardarDatosFisicos').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarDatosFisicos').click(function(e) {
			e.preventDefault();

			_d.cancelarDatosFisicos();

			return false;
		});

	}(window.datosFisicos = window.datosFisicos || {}, window.jQuery));

	// Tripulantes
	(function (tripulantes, $, undefined) {

		var onSuccessOptions = undefined, onNotSuccessOptions = undefined;

		var _t = {

			cleanFields : function() {
				$('#fd_TripulantesCedula').val('');
				$('#fd_TripulantesCedulaMarina').val('');
				$('#fd_TripulantesNombreCompleto').val('');
				$('#fd_TripulantesFechaNacimiento').val('');
				$('#fd_TripulantesLugarNacimiento').val('');
				$('#fd_TripulantesProvinciaNacimiento').val('');
				$('#fd_TripulantesPaisNacimiento').val('');
				$('#fd_TripulantesProfesion').val('');
				$('#fd_TripulantesEstadoCivil').val('');
				$('#fd_TripulantesSexo').val('');
			},

			hideMainBtns : function() {
				$('#fd_MainTripulanteDiv').hide();
			},

			cancelarTripulante : function() {
				_t.cleanFields();

				$('#fd_MainTripulanteDiv').show();

				$('#fd_TripulantesFieldsDiv').hide();
				$('#fd_TripulantesFieldsDivMain').hide();
			},

			showfd_TripulantesFieldsDivMain : function(caption) {
				$('#fd_TripulantesFieldsDivCaption').text(caption);

				_t.hideMainBtns();
				_t.cleanFields();

				$('#fd_TripulantesFieldsDiv').show();
				$('#fd_TripulantesFieldsDivMain').show();
			},

			onGuardarTripulanteSuccess : function(result, optionsSuccess, msg) {

			},

			onGuardarTripulanteNotSuccess : function(optionsNotSuccess, msg) {
				_t.commitTripulante();
			},

			guardarTripulante : function() {
				var cedula = $('#fd_TripulantesCedula').val();

				backendless.db.itemExists('tripulantes', 'cedula', cedula, 
    				onSuccessOptions, onNotSuccessOptions, _t.onGuardarTripulanteSuccess, 
    				_t.onGuardarTripulanteNotSuccess);
			},

			onCommitTripulanteSuccess : function(result, optionsSuccess, msg) {
				console.log('saved');
			},

			onCommitTripulanteNotSuccess: function(optionsNotSuccess, msg) {

			},

			commitTripulante : function() {
				var cedula = $('#fd_TripulantesCedula').val(),
					cedulaMarina = $('#fd_TripulantesCedulaMarina').val(),
					nombreCompleto = $('#fd_TripulantesNombreCompleto').val(),
					sexo = $('#fd_TripulantesSexo').val(),
					fechaNacimiento = $('#fd_TripulantesFechaNacimiento').val(),
					lugarNacimiento = $('#fd_TripulantesLugarNacimiento').val(),
					provinciaNacimiento = $('#fd_TripulantesProvinciaNacimiento').val(),
					paisNacimiento = $('#fd_TripulantesPaisNacimiento').val(),
					profesion = $('#fd_TripulantesProfesion').val(),
					estadoCivil = $('#fd_TripulantesEstadoCivil').val(),

					obj = {cedula: cedula, cedulaMarina: cedulaMarina, nombreCompleto: nombreCompleto,
						sexo: sexo, fechaNacimiento: fechaNacimiento, lugarNacimiento: lugarNacimiento,
						provinciaNacimiento: provinciaNacimiento, paisNacimiento: paisNacimiento,
						profesion: profesion, estadoCivil: estadoCivil};

				backendless.db.itemCreate('tripulantes', JSON.stringify(obj), 
					onSuccessOptions, onNotSuccessOptions, 
					_t.onCommitTripulanteSuccess, _t.onCommitTripulanteNotSuccess);
			},

			isValidTripulantesFields : function() {
				var cedula = $('#fd_TripulantesCedula').val(),
					cedulaMarina = $('#fd_TripulantesCedulaMarina').val(),
					nombreCompleto = $('#fd_TripulantesNombreCompleto').val(),
					sexo = $('#fd_TripulantesSexo').val(),
					fechaNacimiento = $('#fd_TripulantesFechaNacimiento').val(),
					lugarNacimiento = $('#fd_TripulantesLugarNacimiento').val(),
					provinciaNacimiento = $('#fd_TripulantesProvinciaNacimiento').val(),
					paisNacimiento = $('#fd_TripulantesPaisNacimiento').val(),
					profesion = $('#fd_TripulantesProfesion').val(),
					estadoCivil = $('#fd_TripulantesEstadoCivil').val();

				return (isValidAlphaNum(cedulaMarina) && isValidCedula(cedula) && 
					isValidAlphaNumLatin(nombreCompleto) && isValidSexo(sexo) &&
					isValidDate(fechaNacimiento) && isValidCountry(paisNacimiento) && 
					isValidAlphaSpaces(lugarNacimiento) &&
					isValidAlphaSpaces(provinciaNacimiento) && isValidAlphaSpaces(profesion) && 
					isValidEstadoCivil(estadoCivil, sexo));
			},

			checkIsValidTripulantesFields : function() {
				if (_t.isValidTripulantesFields()) {
					$('#fd_GuardarTripulante').removeClass('disabled btn btn-success btn-sm').addClass('btn btn-success btn-sm');
				}
				else {
					$('#fd_GuardarTripulante').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');
				}
			}
		};

		$('#fd_TripulantesCedula').keyup(function (e) {
			fieldOnKey(e, isValidCedula, '#fd_TripulantesCedula', '#fd_TripulantesCedulaNoValida', undefined, '#fd_TripulantesCedulaMarina', false);

			_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesCedulaMarina').keyup(function(e) {
			fieldOnKey(e, isValidAlphaNum, '#fd_TripulantesCedulaMarina', undefined, '#fd_TripulantesCedulaMarinaNoValida', '#fd_TripulantesNombreCompleto', false);

			_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesNombreCompleto').keyup(function(e) {
			fieldOnKey(e, isValidAlphaNumLatin, '#fd_TripulantesNombreCompleto', undefined, '#fd_TripulantesNombreCompletoNoValida', '#fd_TripulantesSexo', false);

			_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesSexo').keyup(function(e) {
			fieldOnKey(e, isValidSexo, '#fd_TripulantesSexo', undefined, '#fd_TripulantesSexoNoValida', '#fd_TripulantesFechaNacimiento', false);

			_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesFechaNacimiento').keyup(function(e) {
			fieldOnKey(e, isValidDateWorkingAge, '#fd_TripulantesFechaNacimiento', undefined, '#fd_TripulantesFechaNacimientoNoValida', '#fd_TripulantesLugarNacimiento', false);

			_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesLugarNacimiento').keyup(function(e) {
			fieldOnKey(e, isValidAlphaSpaces, '#fd_TripulantesLugarNacimiento', undefined, '#fd_TripulantesLugarNacimientoNoValida', '#fd_TripulantesProvinciaNacimiento', false);

			_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesProvinciaNacimiento').keyup(function(e) {
			fieldOnKey(e, isValidAlphaSpaces, '#fd_TripulantesProvinciaNacimiento', undefined, '#fd_TripulantesProvinciaNacimientoNoValida', '#fd_TripulantesPaisNacimiento', false);

			_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesPaisNacimiento').keyup(function(e) {
			fieldOnKey(e, isValidCountry, '#fd_TripulantesPaisNacimiento', undefined, '#fd_TripulantesPaisNacimientoNoValida', '#fd_TripulantesProfesion', false);
			
		  	_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesProfesion').keyup(function(e) {
			fieldOnKey(e, isValidAlphaSpaces, '#fd_TripulantesProfesion', undefined, '#fd_TripulantesProfesionNoValida', '#fd_TripulantesEstadoCivil', false);
			
		  	_t.checkIsValidTripulantesFields();
		});

		$('#fd_TripulantesEstadoCivil').keyup(function(e) {
			fieldOnKey(e, isValidEstadoCivil, '#fd_TripulantesEstadoCivil', '#fd_TripulantesSexo', '#fd_TripulantesEstadoCivilNoValida', undefined, false);
			
		  	_t.checkIsValidTripulantesFields();
		});

		$('#fd_NuevoTripulante').click(function(e) {
			e.preventDefault();

			_t.showfd_TripulantesFieldsDivMain('Nuevo Tripulante');
			$('#fd_TripulantesCedula').focus();

			$('#fd_GuardarTripulante').removeClass('btn btn-success btn-sm').addClass('disabled btn btn-success btn-sm');

			return false;
		});

		$('#fd_CancelarTripulante').click(function(e) {
			e.preventDefault();

			_t.cancelarTripulante();

			return false;
		});

		$('#fd_GuardarTripulante').click(function(e) {
			e.preventDefault();

			_t.guardarTripulante();

			return false;
		});

		tAheadSex = function() {
			var sex = new Bloodhound({
		  		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('value'),
		  		queryTokenizer: Bloodhound.tokenizers.whitespace,
		  		local: $.map(sx, function(s) {
		  			return {value: s}; 
		  		})
			});
		
			sex.initialize();
		 
			$('#fd_TripulantesSexo').typeahead({
		  		hint: true,
		  		highlight: true,
		  		minLength: 1
			},
			{
		  		name: 'sx',
		  		displayKey: 'value',
		  		source: sex.ttAdapter()
			});
		};

		tAheadStates = function() {
			var states = new Bloodhound({
		  		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('value'),
		  		queryTokenizer: Bloodhound.tokenizers.whitespace,
		  		local: $.map(countries, function(state) {
		  			return {value: state}; 
		  		})
			});
		
			states.initialize();
		 
			$('#fd_TripulantesPaisNacimiento').typeahead({
		  		hint: true,
		  		highlight: true,
		  		minLength: 1
			},
			{
		  		name: 'countries',
		  		displayKey: 'value',
		  		source: states.ttAdapter()
			});
		};

		tAheadEstadoCvl = function() {
			var estadoCvl = new Bloodhound({
		  		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('value'),
		  		queryTokenizer: Bloodhound.tokenizers.whitespace,
		  		local: $.map(ec, function(cvl) {
		  			return {value: cvl}; 
		  		})
			});
		
			estadoCvl.initialize();
		 
			$('#fd_TripulantesEstadoCivil').typeahead({
		  		hint: true,
		  		highlight: true,
		  		minLength: 1
			},
			{
		  		name: 'ec',
		  		displayKey: 'value',
		  		source: estadoCvl.ttAdapter()
			});
		};

		tAheadSex();
		tAheadStates();
		tAheadEstadoCvl();

	}(window.tripulantes = window.tripulantes || {}, window.jQuery));
	
	// Main
	(function (main, $, undefined) {
	
		var _m = {
			
			showHidefd_MainBtnsDiv : function(div, opc) {
				if (opc) {
					$('#' + div).show();
				}
				else {
					$('#' + div).hide();
				}
			},

			hideDangerText : function() {
				// Tripulantes
				$('#fd_TripulantesEstadoCivilNoValida').hide();
				$('#fd_TripulantesSexoNoValida').hide();
				$('#fd_TripulantesProfesionNoValida').hide();
				$('#fd_TripulantesPaisNacimientoNoValida').hide();
				$('#fd_TripulantesProvinciaNacimientoNoValida').hide();
				$('#fd_TripulantesLugarNacimientoNoValida').hide();
				$('#fd_TripulantesFechaNacimientoNoValida').hide();
				$('#fd_TripulantesNombreCompletoNoValida').hide();
				$('#fd_TripulantesCedulaMarinaNoValida').hide();
				$('#fd_TripulantesCedulaNoValida').hide();

				// Datos-personales
				$('#fd_DatosPersonalesWebsNoValida').hide();
				$('#fd_DatosPersonalesEmailsNoValida').hide();
				$('#fd_DatosPersonalesDireccionNoValida').hide();
				$('#fd_DatosPersonalesTelefonosNoValida').hide();
				$('#fd_DatosPersonalesCedulaNoValida').hide();

				// Embarques
				$('#fd_EmbarquesBanderaBuqueNoValida').hide();
				$('#fd_EmbarquesPuertoBuqueNoValida').hide();
				$('#fd_EmbarquesCausaDesembarqueNoValida').hide();
				$('#fd_EmbarquesFechaDesembarqueNoValida').hide();
				$('#fd_EmbarquesFechaEmbarqueNoValida').hide();
				$('#fd_EmbarquesCargoBuqueNoValida').hide();
				$('#fd_EmbarquesClaseBuqueNoValida').hide();
				$('#fd_EmbarquesBuqueNoValida').hide();
				$('#fd_EmbarquesCapitanNoValida').hide();
				$('#fd_EmbarquesCedulaNoValida').hide();

				// Idiomas
				$('#fd_IdiomasLugarAprendizajeNoValida').hide();
				$('#fd_IdiomasAcentoNoValida').hide();
				$('#fd_IdiomasNivelHabladoNoValida').hide();
				$('#fd_IdiomasNivelEscritoNoValida').hide();
				$('#fd_IdiomasNivelLecturaNoValida').hide();
				$('#fd_IdiomasNombreNoValida').hide();
				$('#fd_IdiomasCedulaNoValida').hide();

				// Certificados
				$('#fd_CertificadosLugarExpedicionNoValida').hide();
				$('#fd_CertificadosNumeroCertificadoNoValida').hide();
				$('#fd_CertificadosFechaCaducidadNoValida').hide();
				$('#fd_CertificadosFechaExpedicionNoValida').hide();
				$('#fd_CertificadosNombreNoValida').hide();
				$('#fd_CertificadosCedulaNoValida').hide();

				// Datos-fisicos
				$('#fd_DatosFisicosZapatosNoValida').hide();
				$('#fd_DatosFisicosTallaNoValida').hide();
				$('#fd_DatosFisicosEstaturaNoValida').hide();
				$('#fd_DatosFisicosPesoNoValida').hide();
				$('#fd_DatosFisicosCedulaNoValida').hide();

				// Nacionalidades
				$('#fd_NacionalidadesLugarExpedicionNoValida').hide();
				$('#fd_NacionalidadesFechaCaducidadNoValida').hide();
				$('#fd_NacionalidadesFechaExpedicionNoValida').hide();
				$('#fd_NacionalidadesApellidosPasaporteNoValida').hide();
				$('#fd_NacionalidadesNombresPasaporteNoValida').hide();
				$('#fd_NacionalidadesNumeroPasaporteNoValida').hide();
				$('#fd_NacionalidadesNombreNoValida').hide();
				$('#fd_NacionalidadesCedulaNoValida').hide();

				// Visas
				$('#fd_VisasNumeroEntradasNoValida').hide();
				$('#fd_VisasFechaCaducidadNoValida').hide();
				$('#fd_VisasFechaExpedicionNoValida').hide();
				$('#fd_VisasLugarExpedicionNoValida').hide();
				$('#fd_VisasTipoVisaNoValida').hide();
				$('#fd_VisasNumeroPasaporteNoValida').hide();
				$('#fd_VisasCedulaNoValida').hide();

				// Familiares
				$('#fd_FamiliaresFechaDefuncionNoValida').hide();
				$('#fd_FamiliaresParentescoFamiliarNoValida').hide();
				$('#fd_FamiliaresCohabitaFamiliarNoValida').hide();
				$('#fd_FamiliaresDependienteFamiliarNoValida').hide();
				$('#fd_FamiliaresWebsFamiliarNoValida').hide();
				$('#fd_FamiliaresEmailsFamiliarNoValida').hide();
				$('#fd_FamiliaresDireccionFamiliarNoValida').hide();
				$('#fd_FamiliaresTelefonosFamiliarNoValida').hide();
				$('#fd_FamiliaresProfesionFamiliarNoValida').hide();
				$('#fd_FamiliaresPaisNacimientoFamiliarNoValida').hide();
				$('#fd_FamiliaresProvinciaNacimientoFamiliarNoValida').hide();
				$('#fd_FamiliaresLugarNacimientoFamiliarNoValida').hide();
				$('#fd_FamiliaresFechaNacimientoFamiliaNoValida').hide();
				$('#fd_FamiliaresNumeroHijosNoValida').hide();
				$('#fd_FamiliaresHastaFamiliarNoValida').hide();
				$('#fd_FamiliaresDesdeFamiliarNoValida').hide();
				$('#fd_FamiliaresSexoFamiliarNoValida').hide();
				$('#fd_FamiliaresApellidosFamiliarNoValida').hide();
				$('#fd_FamiliaresNombreFamiliarNoValida').hide();
				$('#fd_FamiliaresCedulaFamiliarNoValida').hide();
				$('#fd_FamiliaresCedulaNoValida').hide();

				// Cargos
				$('#fd_CargosDiasPagoNoValida').hide();
				$('#fd_CargosDiasDisfruteNoValida').hide();
				$('#fd_CargosMesesNoValida').hide();
				$('#fd_CargosBonoNoValida').hide();
				$('#fd_CargosSueldoNoValida').hide();
				$('#fd_CargosCargoNoValida').hide();
				$('#fd_CargosCedulaNoValida').hide();

				// Examenes
				$('#fd_ExamenesResultadoExamenNoValida').hide();
				$('#fd_ExamenesFechaCaducidadNoValida').hide();
				$('#fd_ExamenesFechaExamenNoValida').hide();
				$('#fd_ExamenesNombreExamenNoValida').hide();
				$('#fd_ExamenesCedulaNoValida').hide();

				// Clinicas
				$('#fd_ClinicasWebsClinicaNoValida').hide();
				$('#fd_ClinicasEmailsClinicaNoValida').hide();
				$('#fd_ClinicasTelefonosClinicaNoValida').hide();
				$('#fd_ClinicasDireccionClinicaNoValida').hide();
				$('#fd_ClinicasNombreClinicaNoValida').hide();
				$('#fd_ClinicasCedulaNoValida').hide();
			},

			hideForms : function() {
				_m.showHidefd_MainBtnsDiv('fd_TripulantesFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_DatosFisicosFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_DatosPersonalesFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_EmbarquesFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_IdiomasFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_CertificadosFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_NacionalidadesFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_VisasFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_FamiliaresFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_CargosFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_ExamenesFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_ClinicasFieldsDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_Main404Div', false);
			},

			hideBtns : function() {
				_m.showHidefd_MainBtnsDiv('fd_MainTripulanteDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainDatosFisicosDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainDatosPersonalesDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainEmbarquesDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainIdiomasDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainCertificadosDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainNacionalidadesDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainVisasDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainFamiliaresDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainCargosDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainExamenesDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_MainClinicasDiv', false);
				_m.showHidefd_MainBtnsDiv('fd_Main404Div', false);
			},

			setCaptions : function(cMain) {
				$('#captionMain').html(cMain);
			}
		};

		main.hideBtns = function() {
			_m.hideBtns();
		};

		main.hideForms = function() {
			_m.hideForms();
		};

		main.setCaptions = function(cMain, cSmall) {
			_m.setCaptions(cMain, cSmall);
		};

		main.showHidefd_MainBtnsDiv = function(div, opc) {
			_m.showHidefd_MainBtnsDiv(div, opc);
		};
		
		_m.hideBtns();
		_m.hideForms();
		_m.hideDangerText();
	
	}(window.main = window.main || {}, window.jQuery));
	
	// Routing
	(function (main, login, routing, $, undefined) {
	
		var rt = window.location.hash.slice(2);
	
		var _r = {

			homePage : function() {
				
			},

			aboutPage : function() {

			},

			tripulantesPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Tripulantes</small>');
				main.showHidefd_MainBtnsDiv('fd_MainTripulanteDiv', true);
			},

			datosFisicosPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Datos-Fisicos</small>');
				main.showHidefd_MainBtnsDiv('fd_MainDatosFisicosDiv', true);
			},

			datosPersonalesPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Datos-Personales</small>');
				main.showHidefd_MainBtnsDiv('fd_MainDatosPersonalesDiv', true);
			},

			embarquesPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Embarques</small>');
				main.showHidefd_MainBtnsDiv('fd_MainEmbarquesDiv', true);
			},

			idiomasPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Idiomas</small>');
				main.showHidefd_MainBtnsDiv('fd_MainIdiomasDiv', true);
			},

			certificadosPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Certificados</small>');
				main.showHidefd_MainBtnsDiv('fd_MainCertificadosDiv', true);
			},

			nacionalidadesPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Nacionalidades</small>');
				main.showHidefd_MainBtnsDiv('fd_MainNacionalidadesDiv', true);
			},

			visasPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Visas</small>');
				main.showHidefd_MainBtnsDiv('fd_MainVisasDiv', true);
			},

			cargosPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Cargos</small>');
				main.showHidefd_MainBtnsDiv('fd_MainCargosDiv', true);
			},

			familiaresPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Familiares</small>');
				main.showHidefd_MainBtnsDiv('fd_MainFamiliaresDiv', true);
			},

			examenesPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Examenes</small>');
				main.showHidefd_MainBtnsDiv('fd_MainExamenesDiv', true);
			},

			clinicasPage : function() {
				main.hideBtns();
				main.hideForms();

				main.setCaptions('Base de Datos<br><small id="captionSmall">Clinicas</small>');
				main.showHidefd_MainBtnsDiv('fd_MainClinicasDiv', true);
			},
			
			route2Page : function() {

				if (rt === '' && window.location.href.indexOf('#/') < 0) {
                	window.location.href += '#/';
                	_r.homePage();
            	} else if (rt === 'about') {
            		_r.aboutPage();
            	} else if (rt === 'tripulantes') {
            		_r.tripulantesPage();
            	} else if (rt === 'datos-fisicos') {
            		_r.datosFisicosPage();
            	} else if (rt === 'datos-personales') {
            		_r.datosPersonalesPage();
            	} else if (rt === 'embarques') {
            		_r.embarquesPage();
            	} else if (rt === 'idiomas') {
            		_r.idiomasPage();
            	} else if (rt === 'certificados') {
            		_r.certificadosPage();
            	} else if (rt === 'nacionalidades') {
            		_r.nacionalidadesPage();
            	} else if (rt === 'visas') {
            		_r.visasPage();
            	} else if (rt === 'cargos') {
            		_r.cargosPage();
            	} else if (rt === 'familiares') {
            		_r.familiaresPage();
            	} else if (rt === 'examenes') {
            		_r.examenesPage();
            	} else if (rt === 'clinicas') {
            		_r.clinicasPage();
            	}
			},
			
			render404 : function () {
				window.location.href = '#/404';

				main.hideBtns();
				main.hideForms();

				main.setCaptions('404<br><small id="captionSmall">Error</small>');
				main.showHidefd_MainBtnsDiv('fd_Main404Div', true);
			}
		};
		
		var routes = {
			'/': _r.homePage,
			'/about': _r.aboutPage,
			'/tripulantes': _r.tripulantesPage,
			'/datos-personales': _r.datosPersonalesPage,
			'/datos-fisicos': _r.datosFisicosPage,
			'/embarques': _r.embarquesPage,
			'/idiomas': _r.idiomasPage,
			'/certificados': _r.certificadosPage,
			'/nacionalidades': _r.nacionalidadesPage,
			'/visas': _r.visasPage,
			'/familiares': _r.familiaresPage,
			'/cargos': _r.cargosPage,
			'/examenes': _r.examenesPage,
			'/clinicas': _r.clinicasPage
		};
		
		routing.start = function () {
            var router = new Router(routes).configure({
                notfound: _r.render404
            });
            
            router.init();

            _r.route2Page(rt);
        };
		
	}(window.main, window.login, window.routing = window.routing || {}, window.jQuery));

	initDb = function() {
		backendless.init('http://b2sync.aws.af.cm', 'autodocs', 
			'16XD6W96ZFEGYE1GAC82', 'QWvKTHHhWhm9aT3d/zYMySCXXmkZ3Mu/nU2zoZeM', 'us-east-1');
	}

	initDb();
	routing.start();

})(window.jQuery);